void vecAdd(float* A, float* B, float* C, int n);
